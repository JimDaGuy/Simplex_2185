James DiGrazia - SAT Extra Credit

I made the SAT Check return the first non-colliding 
axis found and made it display the colliding plane for 
the x, y, and z tests for obj1 and obj2. Don't know if
you wanted me to explain what I did to accomplish this,
but I created a planeMatrix at the object's model matrix,
rotated the plane to the correct axis, and set it's
position to the midpoint between both objects. Thanks!